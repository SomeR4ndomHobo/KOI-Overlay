Since "/", ":" and "|" cannot be used in file names, change any ocurrence of those to a space " ".

The image will only be exported once you open the program and select the player.
Adding the image here after the player is set or with the program closed will have no effect.